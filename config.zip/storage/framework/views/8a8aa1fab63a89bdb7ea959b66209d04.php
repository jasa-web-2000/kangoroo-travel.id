<?php
    $menu = [['Beranda'], ['Travel', route('arsip-travel')], ['Galeri'], ['Kontak']];

?>

<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a href="<?php echo e($item[1] ?? route(Str::slug($item[0]))); ?>"
            class="whitespace-nowrap <?php echo e(Str::slug($item[0]) == Route::currentRouteName() ? '!text-yellow-700 active' : ''); ?> hover:text-yellow-700 "><?php echo e($item[0]); ?></a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\Dion\Documents\kangoroo-travel.id\kangoroo-travel.id\resources\views/components/nav.blade.php ENDPATH**/ ?>