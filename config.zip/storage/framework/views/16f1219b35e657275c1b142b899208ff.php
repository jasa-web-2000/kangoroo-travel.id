<?php
    $menu = [
        [phone(), whatsapp()],
        // [email(), 'mailto:' . email()],
    ];

?>

<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a target="_blank" href="<?php echo e($item[1] ?? route(Str::slug($item[0]))); ?>"
            class="whitespace-nowrap hover:text-blue-50"><?php echo e($item[0]); ?></a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\Dion\Documents\kangoroo-travel.id\kangoroo-travel.id\resources\views/components/kontak.blade.php ENDPATH**/ ?>