
<?php $__env->startSection('content'); ?>
    <div class="[&_.baner]:pb-40">
        <?php if (isset($component)) { $__componentOriginal87a045471305d9b16f09feaa62783e57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a045471305d9b16f09feaa62783e57 = $attributes; } ?>
<?php $component = App\View\Components\DefaultBaner::resolve(['title' => $title,'desc' => $desc] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('default-baner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DefaultBaner::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a045471305d9b16f09feaa62783e57)): ?>
<?php $attributes = $__attributesOriginal87a045471305d9b16f09feaa62783e57; ?>
<?php unset($__attributesOriginal87a045471305d9b16f09feaa62783e57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a045471305d9b16f09feaa62783e57)): ?>
<?php $component = $__componentOriginal87a045471305d9b16f09feaa62783e57; ?>
<?php unset($__componentOriginal87a045471305d9b16f09feaa62783e57); ?>
<?php endif; ?>
    </div>
    <div class="__container grid place-items-center -my-32 pb-44">
        <?php if (isset($component)) { $__componentOriginal2fb9744565a377a9b2dd9140134e969f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2fb9744565a377a9b2dd9140134e969f = $attributes; } ?>
<?php $component = App\View\Components\TravelSearch::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('travel-search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TravelSearch::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2fb9744565a377a9b2dd9140134e969f)): ?>
<?php $attributes = $__attributesOriginal2fb9744565a377a9b2dd9140134e969f; ?>
<?php unset($__attributesOriginal2fb9744565a377a9b2dd9140134e969f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2fb9744565a377a9b2dd9140134e969f)): ?>
<?php $component = $__componentOriginal2fb9744565a377a9b2dd9140134e969f; ?>
<?php unset($__componentOriginal2fb9744565a377a9b2dd9140134e969f); ?>
<?php endif; ?>
    </div>
    <section class="__container py-24">
        <?php if (isset($component)) { $__componentOriginal879506df025bc33800db5cbd420e556f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal879506df025bc33800db5cbd420e556f = $attributes; } ?>
<?php $component = App\View\Components\Heading::resolve(['title' => 'Pilih Rute','desc1' => 'Bebarapa Rute Unggulan','desc2' => 'Kami merekomendasikan beberapa rute yang jadi pilihan banyak orang.','full' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Heading::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal879506df025bc33800db5cbd420e556f)): ?>
<?php $attributes = $__attributesOriginal879506df025bc33800db5cbd420e556f; ?>
<?php unset($__attributesOriginal879506df025bc33800db5cbd420e556f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal879506df025bc33800db5cbd420e556f)): ?>
<?php $component = $__componentOriginal879506df025bc33800db5cbd420e556f; ?>
<?php unset($__componentOriginal879506df025bc33800db5cbd420e556f); ?>
<?php endif; ?>
        <div class="mt-10">
            <?php if (isset($component)) { $__componentOriginal91a2d118c9c68d158ffcfa4063bf95ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91a2d118c9c68d158ffcfa4063bf95ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.travel-grid','data' => ['featured' => $featured]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.travel-grid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['featured' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($featured)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91a2d118c9c68d158ffcfa4063bf95ee)): ?>
<?php $attributes = $__attributesOriginal91a2d118c9c68d158ffcfa4063bf95ee; ?>
<?php unset($__attributesOriginal91a2d118c9c68d158ffcfa4063bf95ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91a2d118c9c68d158ffcfa4063bf95ee)): ?>
<?php $component = $__componentOriginal91a2d118c9c68d158ffcfa4063bf95ee; ?>
<?php unset($__componentOriginal91a2d118c9c68d158ffcfa4063bf95ee); ?>
<?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dion\Documents\kangoroo-travel.id\kangoroo-travel.id\resources\views/pages/arsip-travel.blade.php ENDPATH**/ ?>