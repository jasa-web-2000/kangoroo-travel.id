
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal87a045471305d9b16f09feaa62783e57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a045471305d9b16f09feaa62783e57 = $attributes; } ?>
<?php $component = App\View\Components\DefaultBaner::resolve(['title' => $page . ' PP Murah ' . date('Y'),'desc' => $desc . '.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('default-baner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DefaultBaner::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a045471305d9b16f09feaa62783e57)): ?>
<?php $attributes = $__attributesOriginal87a045471305d9b16f09feaa62783e57; ?>
<?php unset($__attributesOriginal87a045471305d9b16f09feaa62783e57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a045471305d9b16f09feaa62783e57)): ?>
<?php $component = $__componentOriginal87a045471305d9b16f09feaa62783e57; ?>
<?php unset($__componentOriginal87a045471305d9b16f09feaa62783e57); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal159f23c1702f2667f1808a4b0622f0f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159f23c1702f2667f1808a4b0622f0f8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.article-section','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.article-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        
        <?php if (isset($component)) { $__componentOriginal17c4a23673a4440a1bb06c8c7bab4d4b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17c4a23673a4440a1bb06c8c7bab4d4b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.article-left','data' => ['class' => 'col-span-full lg:col-span-6 lg:pr-24']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.article-left'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-span-full lg:col-span-6 lg:pr-24']); ?>
            
            <img src="<?php echo e($thumbnail); ?>" alt="<?php echo e($title); ?>" title="<?php echo e($title); ?>">

            <p>
                <a title="<?php echo e($page); ?>"
                    href="<?php echo e(route('jalur-rute-travel', [
                        'asal' => Str::slug($travel[0]['name']),
                        'asalId' => $travel[0]['id'],
                        'tujuan' => Str::slug($travel[1]['name']),
                        'tujuanId' => $travel[1]['id'],
                    ])); ?>"><strong><?php echo e($page); ?></strong>
                </a>adalah
                layanan perjalanan transportasi yang membantu anda bepergian
                ke luar kota atau bahkan ke luar provinsi dengan biaya relatif
                murah, jadwal 24 jam, dan pastinya nyaman.
            </p>

            <p>
                Layanan travel door to door kini telah tersedia di banyak kota yang
                ada di Indonesia. Seperti di daerah <?php echo e(Str::title($travel[0]['name'])); ?> ataupun di daerah
                <?php echo e(Str::title($travel[1]['name'])); ?>. Kalo kami, hanya fokus di seluruh Kecamatan,
                Kota/Kabupaten, hingga Provinsi yang ada di Pulau Jawa dan Bali.
            </p>

            <p>
                Jika anda berasal dari <?php echo e(Str::title($travel[0]['name'])); ?>, anda bisa langsung saja menuju
                garasi kami. Anda bisa komunikasi langsung kepada driver dan admin
                untuk memastikan. Namun untuk daerah <?php echo e(Str::title($travel[1]['name'])); ?>, kami hanya
                melayani secara online saja.
            </p>

            <p>
                Jarak dari <?php echo e(Str::title($travel[0]['name'])); ?> menuju <?php echo e(Str::title($travel[1]['name'])); ?> lumayan jauh.
                Jadi
                pastikan anda tidak salah memilih jasa travel. Kami sangat
                memprioritaskan kenyamanan dan keselamatan para pelanggan kami.
            </p>

            <h2>Penyedia Layanan <?php echo e($title); ?> Terbaik</h2>

            <img src="<?php echo e(asset('img/tour-travel.jpg')); ?>" title="Layanan Travel dari <?php echo e(env('APP_NAME')); ?>"
                alt="Layanan
                Travel dari <?php echo e(env('APP_NAME')); ?>">


            <p>
                <a href="<?php echo e(route('beranda')); ?>" title="<?php echo e(route('beranda')); ?>">
                    <?php echo e(env('APP_NAME')); ?></a>
                adalah penyedia jasa travel dengan rute seluruh daerah di Pulau Jawa
                dan Bali. Berusaha untuk terus menjangkau banyak rute agar menjadi
                jasa transportasi terbaik No. 1 di Indonesia. Dan membantu semua
                pelanggan yang ingin bepergian dengan biaya yang murah.
            </p>

            <p>
                Pada tahun 2018, kami sudah mulai membuka layanan pada rute
                <?php echo e(Str::title($travel[0]['name'])); ?> ke <?php echo e(Str::title($travel[1]['name'])); ?> ataupun sebaliknya. Layanan
                yang
                pastinya sangat berkualitas dan terbaik dibanding jasa travel
                lainnya. Hingga saat ini, layanan pada rute ini masih berjalan
                dengan normal.
            </p>

            <h2>Keunggulan Menggunakan Jasa Travel</h2>

            <p>
                Setiap jasa transportasi tentunya memiliki keunggulan tersendiri.
                Namun anda harus menyesuaikan dengan kebutuhan anda dan memilih yang
                terbaik. Jika banyak fasilitas tapi harga tidak cocok, ya mending
                jangan. Jika harga murah namun pelayanan buruk, yang mending jangan
                juga!
            </p>

            <p>
                Berikut kami infokan keunggulan menggunakan jasa travel dari
                <?php echo e(env('APP_NAME')); ?>:
            </p>

            <h3>Harga Murah dan Terjangkau</h3>

            <p>
                Harga murah dan terjangkau kok. Kami tidak bisa melampirkan harga di
                sini. Sebaiknya anda menghubungi admin dan melakukan negosiasi
                langsung. Dengan begitu anda tidak perlu mengeluarkan biaya yang
                banyak.
            </p>

            <p>
                Harga <?php echo e($title); ?> yang kami tawarkan biasanya sudah termasuk biaya
                lainnya, seperti:
            </p>

            <ul>
                <li>Bensin travel</li>
                <li>Free bagasi 15 kg</li>
                <li>Tiket tol jika ada tol</li>
                <li>Bonus makan untuk rute tertentu</li>
                <li>Bonus minum 1 botol dan snack</li>
                <li>Tiket tempat wisata jika tujuan anda ke suatu objek wisata</li>
            </ul>

            <p>
                Nah sudah lumayan murah kan? Jadi tunggu apa lagi, ayo pesan travel
                anda sekarang juga dengan menghubungi admin kami pada nomor whatsapp
                <a title="whatsapp <?php echo e(phone()); ?>" target="_blank" href="<?php echo e(whatsapp()); ?>"
                    rel="nofollow noreferrer noindex">
                    <?php echo e(phone()); ?></a>.
            </p>

            <h3>Harga Travel Didiskon Hingga 10%</h3>

            <p>
                Pada hari-hari tertentu, kami akan memberikan berbagai promo menarik
                yang bisa anda klaim. Salah satunya adalah dikson travel sampai
                dengan 10% per tiket. Promo hanya berlaku untuk 1 tiket ya. Untuk
                mendapatkan promo, silahkan pantau website kami secara berkala, kami
                akan memberikan informasi lebih lanjut.
            </p>

            <h3>Sistem Door to Door</h3>

            <p>
                Terlalu ribet jika berangkat harus datang ke garasi travel. Tenang
                saja kami kini memberikan <strong><?php echo e($page); ?></strong> dengan sistem
                door to door. Kami akan jemput pelanggan langsung dari pintu ke
                pintu. Anda tidak akan diminta tambahan biaya oleh driver. yang
                penting anda telah negosiasikan harga kepada admin ketika melakukan
                pemesanan dan sudah saling setuju.
            </p>

            <h3>Bisa Meminta Pulang Pergi</h3>

            <p>
                Biasanya anda akan hanya diantar sampai tujuan, kemudian driver
                pulang atau mengantar pelanggan lain. Tapi jika anda tidak mau ribet
                melakukan pemesanan ulang Travel <?php echo e(Str::title($travel[1]['name'])); ?> untuk kepulangan,
                maka bisa langsung request saat itu juga. Harga akan sama dengan
                harga ketika berangkat dari <?php echo e(Str::title($travel[0]['name'])); ?>.
            </p>

            <p>
                Cuman, kami tidak langsung mengantar anda pulang karena kami juga
                masih memiliki pelanggan lain yang masih ada di mobil. Jadi, kami
                bisa melakukan pengantaran untuk pulang jika sudah lebih dari 10 jam
                ketika anda tiba.
            </p>

            <p>
                Contoh anda tiba di <?php echo e(Str::title($travel[1]['name'])); ?> pada jam 10 pagi. Kami hanya
                bisa mengantar anda pulang dari <?php echo e(Str::title($travel[1]['name'])); ?> ke
                <?php echo e(Str::title($travel[0]['name'])); ?>

                pada jam 8 malam. Jadi jaraknya sekitar 10 jam.
            </p>

            <h3>Sopir Profesional</h3>

            <p>
                Setiap sopir yang kami miliki telah berpengalaman dalam membawa unit
                ke berbagai daerah di Pulau jawa dan Bali. Mereka juga pasti sudah
                bersertifikat dan berlisensi. Semua sopir bahkan admin harus
                mengikuti SOP yang dimiliki perusahaan. Mereka dituntut ramah dan
                jujur kepada setiap pelanggan.
            </p>

            <p>
                Jika anda mendapati sopir kami membawa mobil dengan ugal-ugalan,
                bersikap tidak sopan, meminta/meminjam uang, maka sebaiknya anda
                melaporkannya pada nomor whatsapp <?php echo e(phone()); ?>.
            </p>

            <h3>Banyak Pilihan Rute Travel</h3>

            <p>
                Tak hanya rute <?php echo e($page); ?>, kami juga memiliki banyak
                <a href="<?php echo e(route('arsip-travel')); ?>" title="rute travel">
                    rute travel</a> lainnya. Berikut daftar rute travel terbaik:
            </p>

            <?php $__currentLoopData = $recommendation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a
                        href="<?php echo e(route('jalur-rute-travel', ['asal' => Str::slug($loop->index < 5 ? $travel[0]['name'] : $travel[1]['name']), 'tujuan' => Str::slug($item['name']), 'asalId' => $loop->index < 5 ? $travel[0]['id'] : $travel[1]['id'], 'tujuanId' => $item['id']])); ?>"><?php echo e(Str::title('Travel ' . ($loop->index < 5 ? $travel[0]['name'] : $travel[1]['name']) . ' ' . $item['name'])); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <img class="mt-5"
                src="<?php echo e(route('thumbnail-jalur-rute-travel', ['asal' => Str::slug($travel[1]['name']), 'tujuan' => Str::slug($travel[0]['name']), 'asalId' => $travel[1]['id'], 'tujuanId' => $travel[0]['id']])); ?>"
                alt="Travel <?php echo e($travel[1]['name']); ?> <?php echo e($travel[0]['name']); ?>"
                title="Travel <?php echo e($travel[1]['name']); ?> <?php echo e($travel[0]['name']); ?>">




            <h2>Jadwal Keberangkatan Travel</h2>

            <p>
                Kami akan berusaha membuat jadwal sefleksibel mungkin. Anda tidak
                perlu khawatir terlambat jika menggunakan jasa travel dari kami.
                Memilih <?php echo e(env('APP_NAME')); ?> sangat rekomendasi karena memiliki jadwal keberangkatan
                setiap hari. Untuk jamnya sendiri sangat bervariasi tapi tetap 24
                jam. untuk lebih lanjut silahkan tanyakan kepada admin.
            </p>

            <p>
                Tapi, jika anda memesan carter pada travel <?php echo e(Str::title($travel[1]['name'])); ?>, anda
                bisa memilih jam keberangkatan kapan saja yang anda mau. Carter
                hampir mirip seperti rental mobil plus driver. Jadi semua kebutuhan
                anda akan kami sanggupi.
            </p>

            <h2>Armada/Unit/Mobil Travel</h2>

            <p>
                Banyak armada/unit/mobil yang kami miliki, mulai dari Hiace, Elf
                Long, Innova, Avanza, Xenia, Calya, dan lain-lain. Untuk jasa travel
                reguler, anda tidak bisa memilih mobil yang akan digunakan, namun
                anda dijamin akan tetap nyaman selama perjalanan.
            </p>

            <p>
                Semua mobil tersebut telah dilengkapi dengan ac. Tidak akan merasa
                panas selama perjalanan. Sopir maupun pelanggan juga tidak boleh
                merokok. Kursi juga sudah bisa direbahkan (Reclining seat), jadi
                bisa anda sesuaikan untuk kenyamanan.
            </p>

            <h2>Pesan Tiket <?php echo e($page); ?> Sekarang!</h2>

            <p>
                Pemesanan travel sangat mudah. Anda bisa melakukannya secara daring.
                Cukup hubungi nomor whatsapp <?php echo e(phone()); ?> dan anda akan
                disuruh untuk mengisi form reservasi. Simpan form reservasinya
                sebaik mungkin. Anda akan diminta oleh driver ketika menaiki mobil.
            </p>

            <p>
                Khusus pemesanan untuk Hari
                <?php echo e(\Carbon\Carbon::now()->addDay()->locale('id')->isoFormat('dddd, D MMMM YYYY')); ?>, anda
                akan mendapatkan diskon 10%. Cukup dengan mengklik tombol whatsapp di kanan bawah layar maka
                anda otomatis diarahkan ke whatsapp admin kami.
            </p>

            <p>
                Jadi tunggu apa lagi, pesan travel sekarang juga. Jangan sampai
                kehabisan tiket. Travel ini memiliki sistem door to door, pulang
                pergi, 24 jam, via tol, bonus makan. Dengan <strong><?php echo e($title); ?></strong>
                Kami siap antar jemput anda kapanpun anda mau.
            </p>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17c4a23673a4440a1bb06c8c7bab4d4b)): ?>
<?php $attributes = $__attributesOriginal17c4a23673a4440a1bb06c8c7bab4d4b; ?>
<?php unset($__attributesOriginal17c4a23673a4440a1bb06c8c7bab4d4b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17c4a23673a4440a1bb06c8c7bab4d4b)): ?>
<?php $component = $__componentOriginal17c4a23673a4440a1bb06c8c7bab4d4b; ?>
<?php unset($__componentOriginal17c4a23673a4440a1bb06c8c7bab4d4b); ?>
<?php endif; ?>



        
        <?php if (isset($component)) { $__componentOriginalce3cc09b41fabec0e4da8b4d854711be = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce3cc09b41fabec0e4da8b4d854711be = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.article-right','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.article-right'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php if (isset($component)) { $__componentOriginal5379d7c313a3003ffeb1e9f8c8b1be8a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5379d7c313a3003ffeb1e9f8c8b1be8a = $attributes; } ?>
<?php $component = App\View\Components\Booking::resolve(['page' => $page] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('booking'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Booking::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5379d7c313a3003ffeb1e9f8c8b1be8a)): ?>
<?php $attributes = $__attributesOriginal5379d7c313a3003ffeb1e9f8c8b1be8a; ?>
<?php unset($__attributesOriginal5379d7c313a3003ffeb1e9f8c8b1be8a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5379d7c313a3003ffeb1e9f8c8b1be8a)): ?>
<?php $component = $__componentOriginal5379d7c313a3003ffeb1e9f8c8b1be8a; ?>
<?php unset($__componentOriginal5379d7c313a3003ffeb1e9f8c8b1be8a); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce3cc09b41fabec0e4da8b4d854711be)): ?>
<?php $attributes = $__attributesOriginalce3cc09b41fabec0e4da8b4d854711be; ?>
<?php unset($__attributesOriginalce3cc09b41fabec0e4da8b4d854711be); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce3cc09b41fabec0e4da8b4d854711be)): ?>
<?php $component = $__componentOriginalce3cc09b41fabec0e4da8b4d854711be; ?>
<?php unset($__componentOriginalce3cc09b41fabec0e4da8b4d854711be); ?>
<?php endif; ?>


     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159f23c1702f2667f1808a4b0622f0f8)): ?>
<?php $attributes = $__attributesOriginal159f23c1702f2667f1808a4b0622f0f8; ?>
<?php unset($__attributesOriginal159f23c1702f2667f1808a4b0622f0f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159f23c1702f2667f1808a4b0622f0f8)): ?>
<?php $component = $__componentOriginal159f23c1702f2667f1808a4b0622f0f8; ?>
<?php unset($__componentOriginal159f23c1702f2667f1808a4b0622f0f8); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dion\Documents\kangoroo-travel.id\kangoroo-travel.id\resources\views/pages/travel.blade.php ENDPATH**/ ?>