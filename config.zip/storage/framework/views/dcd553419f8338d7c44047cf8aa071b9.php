
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginale6f5e38de5b677e36508509dcb8b1ae2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6f5e38de5b677e36508509dcb8b1ae2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.home.baner','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.home.baner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6f5e38de5b677e36508509dcb8b1ae2)): ?>
<?php $attributes = $__attributesOriginale6f5e38de5b677e36508509dcb8b1ae2; ?>
<?php unset($__attributesOriginale6f5e38de5b677e36508509dcb8b1ae2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6f5e38de5b677e36508509dcb8b1ae2)): ?>
<?php $component = $__componentOriginale6f5e38de5b677e36508509dcb8b1ae2; ?>
<?php unset($__componentOriginale6f5e38de5b677e36508509dcb8b1ae2); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal77a7798d0e0c4f6e28893c5e57968a04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal77a7798d0e0c4f6e28893c5e57968a04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.home.advantages','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.home.advantages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal77a7798d0e0c4f6e28893c5e57968a04)): ?>
<?php $attributes = $__attributesOriginal77a7798d0e0c4f6e28893c5e57968a04; ?>
<?php unset($__attributesOriginal77a7798d0e0c4f6e28893c5e57968a04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal77a7798d0e0c4f6e28893c5e57968a04)): ?>
<?php $component = $__componentOriginal77a7798d0e0c4f6e28893c5e57968a04; ?>
<?php unset($__componentOriginal77a7798d0e0c4f6e28893c5e57968a04); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal99051082bb43ac409be5a06e77f778c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99051082bb43ac409be5a06e77f778c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.home.featured','data' => ['featured' => $featured]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.home.featured'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['featured' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($featured)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99051082bb43ac409be5a06e77f778c4)): ?>
<?php $attributes = $__attributesOriginal99051082bb43ac409be5a06e77f778c4; ?>
<?php unset($__attributesOriginal99051082bb43ac409be5a06e77f778c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99051082bb43ac409be5a06e77f778c4)): ?>
<?php $component = $__componentOriginal99051082bb43ac409be5a06e77f778c4; ?>
<?php unset($__componentOriginal99051082bb43ac409be5a06e77f778c4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal6425dc5d14a70f8accda7036e3b080ce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6425dc5d14a70f8accda7036e3b080ce = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.gallery','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.gallery'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6425dc5d14a70f8accda7036e3b080ce)): ?>
<?php $attributes = $__attributesOriginal6425dc5d14a70f8accda7036e3b080ce; ?>
<?php unset($__attributesOriginal6425dc5d14a70f8accda7036e3b080ce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6425dc5d14a70f8accda7036e3b080ce)): ?>
<?php $component = $__componentOriginal6425dc5d14a70f8accda7036e3b080ce; ?>
<?php unset($__componentOriginal6425dc5d14a70f8accda7036e3b080ce); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal81709b6b18b0fa5288eda28161457c4b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81709b6b18b0fa5288eda28161457c4b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.cta','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.cta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81709b6b18b0fa5288eda28161457c4b)): ?>
<?php $attributes = $__attributesOriginal81709b6b18b0fa5288eda28161457c4b; ?>
<?php unset($__attributesOriginal81709b6b18b0fa5288eda28161457c4b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81709b6b18b0fa5288eda28161457c4b)): ?>
<?php $component = $__componentOriginal81709b6b18b0fa5288eda28161457c4b; ?>
<?php unset($__componentOriginal81709b6b18b0fa5288eda28161457c4b); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal8e6206b5ac152f8dcac5cf7016d5cc76 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e6206b5ac152f8dcac5cf7016d5cc76 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.home.testimonials','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.home.testimonials'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e6206b5ac152f8dcac5cf7016d5cc76)): ?>
<?php $attributes = $__attributesOriginal8e6206b5ac152f8dcac5cf7016d5cc76; ?>
<?php unset($__attributesOriginal8e6206b5ac152f8dcac5cf7016d5cc76); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e6206b5ac152f8dcac5cf7016d5cc76)): ?>
<?php $component = $__componentOriginal8e6206b5ac152f8dcac5cf7016d5cc76; ?>
<?php unset($__componentOriginal8e6206b5ac152f8dcac5cf7016d5cc76); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dion\Documents\kangoroo-travel.id\kangoroo-travel.id\resources\views/pages/home.blade.php ENDPATH**/ ?>