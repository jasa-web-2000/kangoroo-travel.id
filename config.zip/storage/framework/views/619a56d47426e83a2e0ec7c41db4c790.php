<?php if (isset($component)) { $__componentOriginalf4088b6e5430c3c69553619df6e257df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf4088b6e5430c3c69553619df6e257df = $attributes; } ?>
<?php $component = App\View\Components\BackgroundBlue::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('background-blue'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BackgroundBlue::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="__container">
        <div class="baner py-14 md:py-24 text-center max-w-[700px] mx-auto">
            <h1 class="text-white mb-5"><?php echo e($title); ?></h1>
            <p class="px-5 max-w-[550px] mx-auto text-slate-100"><?php echo e($desc); ?></p>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf4088b6e5430c3c69553619df6e257df)): ?>
<?php $attributes = $__attributesOriginalf4088b6e5430c3c69553619df6e257df; ?>
<?php unset($__attributesOriginalf4088b6e5430c3c69553619df6e257df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf4088b6e5430c3c69553619df6e257df)): ?>
<?php $component = $__componentOriginalf4088b6e5430c3c69553619df6e257df; ?>
<?php unset($__componentOriginalf4088b6e5430c3c69553619df6e257df); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Dion\Documents\kangoroo-travel.id\kangoroo-travel.id\resources\views/components/default-baner.blade.php ENDPATH**/ ?>