<div class="py-24 __container">
    <?php if (isset($component)) { $__componentOriginal879506df025bc33800db5cbd420e556f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal879506df025bc33800db5cbd420e556f = $attributes; } ?>
<?php $component = App\View\Components\Heading::resolve(['title' => 'Galeri Travel','desc1' => 'Abadikan Momen Perjalanan Anda','desc2' => 'Galeri ini menampilkan berbagai unit, foto, dan momen berharga yang merefleksikan perjalanan kami.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Heading::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal879506df025bc33800db5cbd420e556f)): ?>
<?php $attributes = $__attributesOriginal879506df025bc33800db5cbd420e556f; ?>
<?php unset($__attributesOriginal879506df025bc33800db5cbd420e556f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal879506df025bc33800db5cbd420e556f)): ?>
<?php $component = $__componentOriginal879506df025bc33800db5cbd420e556f; ?>
<?php unset($__componentOriginal879506df025bc33800db5cbd420e556f); ?>
<?php endif; ?>
    <div
        class="max-w-2xl lg:max-w-4xl !mx-auto grid grid-cols-12 sm:gap-x-6 gap-y-8 mt-10 [&>*]:overflow-hidden [&>div]:cursor-pointer [&>div]:w-full [&>div]:rounded-2xl [&>div]:shadow-lg [&>div]:h-72 [&>div]:col-span-full [&>div]:border-8 [&>div]:border-yellow-600 [&_img]:w-full [&_img]:h-full [&_img]:object-cover [&_img]:rounded-lg [&_img]:transition-all [&_img]:duration-700 [&_img]:brightness-50 hover:[&_img]:brightness-75">
        
        <div class="sm:!col-span-8">
            <img loading="lazy" width="100" height="100" src="<?php echo e(asset('img/gallery/1.jpg')); ?>" alt="galeri 1">
        </div>
        <div class="sm:!col-span-4">
            <img loading="lazy" width="100" height="100" src="<?php echo e(asset('img/gallery/2.jpg')); ?>" alt="galeri 2">
        </div>
        <div class="sm:!col-span-6">
            <img loading="lazy" width="100" height="100" src="<?php echo e(asset('img/gallery/5.jpg')); ?>" alt="galeri 5">
        </div>
        <div class="sm:!col-span-6">
            <img loading="lazy" width="100" height="100" src="<?php echo e(asset('img/gallery/6.jpg')); ?>" alt="galeri 6">
        </div>
        <div class="sm:!col-span-4">
            <img loading="lazy" width="100" height="100" src="<?php echo e(asset('img/gallery/3.jpg')); ?>" alt="galeri 3">
        </div>
        <div class="sm:!col-span-8">
            <img loading="lazy" width="100" height="100" src="<?php echo e(asset('img/gallery/4.jpg')); ?>" alt="galeri 4">
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Dion\Documents\kangoroo-travel.id\kangoroo-travel.id\resources\views/components/layouts/gallery.blade.php ENDPATH**/ ?>