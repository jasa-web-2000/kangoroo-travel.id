<?php if(isset($errors) && $errors->any()): ?>
    <div class="animate-alert max-w-[min(80%,300px)] w-auto bg-gray-100 shadow-2xl z-[99] border-l-[10px] border-l-blue-700 fixed bottom-5 left-5"
        id="alert">
        <?php if (isset($component)) { $__componentOriginala87d31c5bcfccaf1edac3b52ba0506c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala87d31c5bcfccaf1edac3b52ba0506c6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.animate-expand','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('animate-expand'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala87d31c5bcfccaf1edac3b52ba0506c6)): ?>
<?php $attributes = $__attributesOriginala87d31c5bcfccaf1edac3b52ba0506c6; ?>
<?php unset($__attributesOriginala87d31c5bcfccaf1edac3b52ba0506c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala87d31c5bcfccaf1edac3b52ba0506c6)): ?>
<?php $component = $__componentOriginala87d31c5bcfccaf1edac3b52ba0506c6; ?>
<?php unset($__componentOriginala87d31c5bcfccaf1edac3b52ba0506c6); ?>
<?php endif; ?>

        <div class="relative flex justify-between flex-row-reverse items-start p-4 pr-2">
            <button id="closeAlert" class="">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor" class=" size-5 stroke-blue-500">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="m9.75 9.75 4.5 4.5m0-4.5-4.5 4.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                </svg>
            </button>
            <div class="text-[13px] pr-6">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="<?php echo e($loop->count == 1 ? '' : 'list-disc'); ?> ml-2"><?php echo e($item); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>

    </div>
    <script>
        const alert = document.querySelector('#alert')
        const closeAlert = document.querySelector('#closeAlert')

        if (alert && closeAlert) {
            closeAlert.addEventListener('click', e => {
                alert.classList.add('!hidden')
            })
            setInterval(() => {
                alert.classList.add('!hidden')
            }, 6000);
        }
    </script>
<?php endif; ?>
<?php /**PATH C:\Users\Dion\Documents\kangoroo-travel.id\kangoroo-travel.id\resources\views/components/alert.blade.php ENDPATH**/ ?>