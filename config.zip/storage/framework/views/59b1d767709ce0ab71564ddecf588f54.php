<div class="bg-slate-200">

    <div class="py-24 __container">
        <div class="">
            <?php if (isset($component)) { $__componentOriginal879506df025bc33800db5cbd420e556f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal879506df025bc33800db5cbd420e556f = $attributes; } ?>
<?php $component = App\View\Components\Heading::resolve(['title' => 'Testimoni Pelanggan','desc1' => 'Pendapat Mereka Tentang Layanan Kami','desc2' => 'Apa saja ulasan mereka setelah menggunakan layanan dari kami?'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Heading::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal879506df025bc33800db5cbd420e556f)): ?>
<?php $attributes = $__attributesOriginal879506df025bc33800db5cbd420e556f; ?>
<?php unset($__attributesOriginal879506df025bc33800db5cbd420e556f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal879506df025bc33800db5cbd420e556f)): ?>
<?php $component = $__componentOriginal879506df025bc33800db5cbd420e556f; ?>
<?php unset($__componentOriginal879506df025bc33800db5cbd420e556f); ?>
<?php endif; ?>
            <div class="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-4xl">

                <div
                    class="mx-auto max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-4xl custom-container flex flex-col items-center justify-center text-center mb-10 mt-16">
                    <div class="grid gap-10 md:grid-cols-2 xl:grid-cols-3">
                        <?php if (isset($component)) { $__componentOriginal867564707b3e77941dae1c0fd0aebcff = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal867564707b3e77941dae1c0fd0aebcff = $attributes; } ?>
<?php $component = App\View\Components\Testimoni::resolve(['text' => 'Perjalanan Travel saya dari Jakarta ke Cirebon benar-benar <mark class=\'px-2 mx-1 text-mine bg-yellow-100 rounded-md ring-yellow-200 ring-2\'>nyaman</mark>! Mobil Elf Long yang digunakan bersih, AC-nya dingin, dan sopirnya sangat profesional. Saya bisa istirahat dengan tenang sepanjang jalan tanpa merasa pegal. Terima kasih, pasti akan pakai jasa ini lagi!','name' => 'Ahmad Fauzi','job' => 'Dosen','img' => ''.e(asset('img/testimonial/gal1.webp')).'','className' => 'xl:col-span-1 md:col-span-2'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('testimoni'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Testimoni::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal867564707b3e77941dae1c0fd0aebcff)): ?>
<?php $attributes = $__attributesOriginal867564707b3e77941dae1c0fd0aebcff; ?>
<?php unset($__attributesOriginal867564707b3e77941dae1c0fd0aebcff); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal867564707b3e77941dae1c0fd0aebcff)): ?>
<?php $component = $__componentOriginal867564707b3e77941dae1c0fd0aebcff; ?>
<?php unset($__componentOriginal867564707b3e77941dae1c0fd0aebcff); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal867564707b3e77941dae1c0fd0aebcff = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal867564707b3e77941dae1c0fd0aebcff = $attributes; } ?>
<?php $component = App\View\Components\Testimoni::resolve(['text' => 'Layanan travelnya sangat membantu! Saya pakai untuk mengantar orang tua ke bandara sebelum keberangkatan umroh. Mobilnya bersih, sopirnya ramah dan on time. Kami sekeluarga <mark class=\'px-2 mx-1 text-mine bg-yellow-100 rounded-md ring-yellow-200 ring-2\'>merasa tenang</mark> karena semuanya berjalan lancar tanpa terburu-buru. Terima kasih atas pelayanannya!','name' => 'Samsul Bahri','job' => 'Konsultan Syariah','img' => ''.e(asset('img/testimonial/gal2.webp')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('testimoni'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Testimoni::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal867564707b3e77941dae1c0fd0aebcff)): ?>
<?php $attributes = $__attributesOriginal867564707b3e77941dae1c0fd0aebcff; ?>
<?php unset($__attributesOriginal867564707b3e77941dae1c0fd0aebcff); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal867564707b3e77941dae1c0fd0aebcff)): ?>
<?php $component = $__componentOriginal867564707b3e77941dae1c0fd0aebcff; ?>
<?php unset($__componentOriginal867564707b3e77941dae1c0fd0aebcff); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal867564707b3e77941dae1c0fd0aebcff = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal867564707b3e77941dae1c0fd0aebcff = $attributes; } ?>
<?php $component = App\View\Components\Testimoni::resolve(['text' => 'Saya pulang dari kampus ke rumah saat Lebaran pakai jasa travel ini, dan alhamdulillah perjalanannya sangat nyaman. Supirnya <mark class=\'px-2 mx-1 text-mine bg-yellow-100 rounded-md ring-yellow-200 ring-2\'>ramah</mark>, mobilnya <mark class=\'px-2 mx-1 text-mine bg-yellow-100 rounded-md ring-yellow-200 ring-2\'>bersih</mark> dan <mark class=\'px-2 mx-1 text-mine bg-yellow-100 rounded-md ring-yellow-200 ring-2\'>adem</mark>, jadi nggak terasa jauh. Orang tua saya juga senang karena saya bisa sampai rumah dengan selamat dan tepat waktu. Terima kasih banyak!','name' => 'Dewi Lestari','job' => 'Mahasiswi','img' => ''.e(asset('img/testimonial/gal3.webp')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('testimoni'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Testimoni::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal867564707b3e77941dae1c0fd0aebcff)): ?>
<?php $attributes = $__attributesOriginal867564707b3e77941dae1c0fd0aebcff; ?>
<?php unset($__attributesOriginal867564707b3e77941dae1c0fd0aebcff); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal867564707b3e77941dae1c0fd0aebcff)): ?>
<?php $component = $__componentOriginal867564707b3e77941dae1c0fd0aebcff; ?>
<?php unset($__componentOriginal867564707b3e77941dae1c0fd0aebcff); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\Users\Dion\Documents\kangoroo-travel.id\kangoroo-travel.id\resources\views/components/layouts/home/testimonials.blade.php ENDPATH**/ ?>