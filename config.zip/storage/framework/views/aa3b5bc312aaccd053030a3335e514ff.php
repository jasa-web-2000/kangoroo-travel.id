<div class="col-span-full lg:col-span-3 pt-[60px] text-center">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\Dion\Documents\kangoroo-travel.id\kangoroo-travel.id\resources\views/components/layouts/article-right.blade.php ENDPATH**/ ?>