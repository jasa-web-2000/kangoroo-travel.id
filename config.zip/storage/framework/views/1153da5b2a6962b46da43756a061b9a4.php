<div class="col-span-full lg:col-span-6 lg:pr-24">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\Dion\Documents\kangoroo-travel.id\kangoroo-travel.id\resources\views/components/layouts/article-left.blade.php ENDPATH**/ ?>