<div class="__gradient">
    <div class="bg-right-bottom " style="background-image: url({{ asset('img/blob.svg') }})">
        {{ $slot }}
    </div>
</div>
