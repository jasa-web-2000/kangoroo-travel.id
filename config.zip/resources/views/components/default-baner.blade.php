<x-background-blue>
    <div class="__container">
        <div class="baner py-14 md:py-24 text-center max-w-[700px] mx-auto">
            <h1 class="text-white mb-5">{{ $title }}</h1>
            <p class="px-5 max-w-[550px] mx-auto text-slate-100">{{ $desc }}</p>
        </div>
    </div>
</x-background-blue>
