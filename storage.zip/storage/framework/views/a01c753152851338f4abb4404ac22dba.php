<article>
    <section id="content"
        class="__container !mx-auto md:!max-w-[800px] lg:!max-w-[1240px] grid grid-cols-9 text-justify !py-12">
        <?php echo e($slot); ?>

    </section>
</article>
<?php /**PATH C:\xampp\htdocs\travel\armantrans.com\resources\views/components/layouts/article-section.blade.php ENDPATH**/ ?>