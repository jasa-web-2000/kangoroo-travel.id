<div class="w-full !mx-0 grid place-items-center __gradient py-20 relative">
    <div class="top-0 left-0 w-full opacity-[0.04] !bg-fixed h-full absolute !z-[2] !bg-[length:80px_80px]"
        style="background: url(<?php echo e(asset('img/bg-baner.png')); ?>) ">
    </div>
    <div class="text-center z-[3] px-2">
        <h1 class="!text-white mb-2"><?php echo e(config('app.name') . ' - Travel Murah ' . date('Y')); ?></h1>
        <p class="text-slate-200 mb-7 max-w-[450px] mx-auto"><?php echo e(config('app.name')); ?> akan membantu merencanakan travel anda dengan aman, nyaman, dan harga murah!</p>
    </div>
    <div class="w-full !z-[2] px-5">
        <div class="container mx-auto flex justify-center items-center ">
            <?php if (isset($component)) { $__componentOriginal2fb9744565a377a9b2dd9140134e969f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2fb9744565a377a9b2dd9140134e969f = $attributes; } ?>
<?php $component = App\View\Components\TravelSearch::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('travel-search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\TravelSearch::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2fb9744565a377a9b2dd9140134e969f)): ?>
<?php $attributes = $__attributesOriginal2fb9744565a377a9b2dd9140134e969f; ?>
<?php unset($__attributesOriginal2fb9744565a377a9b2dd9140134e969f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2fb9744565a377a9b2dd9140134e969f)): ?>
<?php $component = $__componentOriginal2fb9744565a377a9b2dd9140134e969f; ?>
<?php unset($__componentOriginal2fb9744565a377a9b2dd9140134e969f); ?>
<?php endif; ?>
            
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\travel\armantrans.com\resources\views/components/layouts/home/baner.blade.php ENDPATH**/ ?>