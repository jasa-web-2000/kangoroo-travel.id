<div class="">
    <select <?php echo e($required ? 'required' : ''); ?> <?php echo e($area->count() < 1 ? 'disabled' : ''); ?>

        class="w-full border cursor-pointer text-sm border-slate-300 p-2 rounded focus:border-yellow-700 focus:outline-yellow-700 <?php echo e($area->count() < 1 ? 'bg-gray-200/70 !cursor-not-allowed' : ''); ?>"
        wire:model.live="selected<?php echo e($model); ?>" name="<?php echo e(Str::slug($name) . '_' . Str::slug($title)); ?>">
        <option value="">Pilih <?php echo e($title); ?></option>

        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value=<?php echo e($item->code); ?>><?php echo e(Str::title($item->name)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="" disabled>Tidak Ada Data</option>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </select>
</div>
<?php /**PATH C:\xampp\htdocs\travel\armantrans.com\resources\views/components/select.blade.php ENDPATH**/ ?>