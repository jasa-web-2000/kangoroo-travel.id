<a href="<?php echo e(route('beranda')); ?>" class="block w-16 md:w-20">
    <img class="w-full h-auto" loading="lazy" src="<?php echo e($light ? asset('img/travel.png') : asset('img/travel.png')); ?>"
        alt="Logo <?php echo e(config('app.name')); ?>">
</a>
<?php /**PATH C:\xampp\htdocs\travel\armantrans.com\resources\views/components/logo.blade.php ENDPATH**/ ?>