
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal87a045471305d9b16f09feaa62783e57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a045471305d9b16f09feaa62783e57 = $attributes; } ?>
<?php $component = App\View\Components\DefaultBaner::resolve(['title' => $page . ' PP Murah ' . date('Y'),'desc' => $desc . '.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('default-baner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DefaultBaner::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a045471305d9b16f09feaa62783e57)): ?>
<?php $attributes = $__attributesOriginal87a045471305d9b16f09feaa62783e57; ?>
<?php unset($__attributesOriginal87a045471305d9b16f09feaa62783e57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a045471305d9b16f09feaa62783e57)): ?>
<?php $component = $__componentOriginal87a045471305d9b16f09feaa62783e57; ?>
<?php unset($__componentOriginal87a045471305d9b16f09feaa62783e57); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal159f23c1702f2667f1808a4b0622f0f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159f23c1702f2667f1808a4b0622f0f8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.article-section','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.article-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        
        <?php if (isset($component)) { $__componentOriginal17c4a23673a4440a1bb06c8c7bab4d4b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17c4a23673a4440a1bb06c8c7bab4d4b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.article-left','data' => ['class' => 'col-span-full lg:col-span-6 lg:pr-24']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.article-left'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-span-full lg:col-span-6 lg:pr-24']); ?>

            
            <h2><?php echo e($title); ?></h2>
            <img src="<?php echo e($thumbnail); ?>" alt="<?php echo e($title); ?>">
            <p>
                <a href="<?php echo e(route('beranda')); ?>"><?php echo e(Str::upper(env('APP_NAME'))); ?></a> siap menemani perjalanan Anda dan
                keluarga dengan layanan antar-jemput dari
                <?php echo e(Str::title($travel[0]->name)); ?> menuju <?php echo e(Str::title($travel[1]->name)); ?> serta sebaliknya dari
                <?php echo e(Str::title($travel[1]->name)); ?> ke <?php echo e(Str::title($travel[0]->name)); ?>. Kami mengutamakan keamanan,
                kenyamanan, dan ketepatan waktu agar perjalanan Anda selalu menyenangkan dan sampai dengan selamat.
            </p>
            <p>Saat memilih jasa travel, Anda perlu berhati-hati dan disarankan untuk melakukan pembayaran setelah tiba di
                tujuan. Saat ini, modus penipuan semakin marak di sektor jasa travel reguler, dengan banyak agen atau travel
                palsu yang menawarkan harga murah namun tidak dapat dipercaya.
            </p>
            
            <h3>Harga Tiket Travel Terjangkau</h3>
            <p>
                Kami menyediakan jasa travel dengan harga yang terjangkau dan ramah di kantong. Jika Anda merasa perlu, Anda
                juga dapat langsung bernegosiasi dengan admin kami. Jangan ragu untuk menghubungi kami kapan saja, kami siap
                membantu menemukan solusi biaya terbaik untuk Anda.
            </p>
            <p>
                Biaya perjalanan dari <?php echo e(Str::title($travel[0]->name)); ?> ke <?php echo e(Str::title($travel[1]->name)); ?> bersifat
                dinamis dan dapat berubah sesuai kondisi. Untuk mendapatkan tarif terbaik, sebaiknya pesan tiket travel
                melalui <strong><?php echo e($page); ?></strong> paling lambat 1 hari sebelum keberangkatan. Jika memesan
                terlalu dekat dengan jadwal keberangkatan, harga tiket cenderung meningkat, terutama saat momen hari raya
                atau libur panjang.
            </p>
            
            <h3>Jadwal Travel Sangat Responsif</h3>
            <p>Setiap layanan travel memiliki jadwal keberangkatan yang berbeda-beda, begitu juga dengan kami. Kami melayani
                keberangkatan setiap hari pada waktu-waktu tertentu. Harap pastikan Anda sudah siap di lokasi penjemputan
                sesuai jadwal yang telah ditentukan. Apabila Anda telah melakukan pembayaran tetapi tidak berada di titik
                penjemputan saat waktu jemput, kami hanya mengembalikan 50% dari biaya.
            </p>
            <p>
                Namun, jika sopir terlambat
                menjemput, Anda akan diantar tanpa biaya tambahan, meskipun fasilitas makan gratis tidak diberikan. Berikut
                adalah jadwal keberangkatan kami:
            </p>
            
            <div class="relative rounded-xl overflow-auto">
                <div class="shadow-sm overflow-x-auto my-4">
                    <table class="border-collapse table-auto w-full">
                        <thead class="bg-white">
                            <tr
                                class=" [&_th]:border-b [&_th]:font-medium [&_th]:whitespace-nowrap [&_th]:p-4 [&_th]:pb-3 [&_th]:text-slate-700 [&_th]:w-1/2">
                                <th class="!pl-8">
                                    Dari <?php echo e(Str::title($travel[0]->name)); ?></th>
                                <th class="!pr-8">
                                    Dari <?php echo e(Str::title($travel[1]->name)); ?></th>
                            </tr>
                        </thead>
                        <tbody class="bg-white">
                            <?php
                                $jadwal = [
                                    ['06', '07'],
                                    ['08', '10'],
                                    ['11', '11'],
                                    ['14', '13'],
                                    ['15', '15'],
                                    ['17', '18'],
                                    ['19', '21'],
                                    ['21', '22'],
                                ];
                            ?>

                            <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="[&_td]:border-b [&_td]:border-slate-200 [&_td]:p-4 [&_td]:text-slate-500">
                                    <td class="!pl-8">
                                        <?php echo e($item[0]); ?>:00 WIB</td>
                                    <td class="pr-8">
                                        <?php echo e($item[1]); ?>:00 WIB</td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <p>
                Jadwal keberangkatan dapat berubah sewaktu-waktu. Jika Anda ingin berangkat pada waktu yang tidak tercantum
                dalam tabel, silakan lakukan pemesanan carter langsung dengan admin. Waktu dan hari keberangkatan bisa
                disesuaikan sesuai kebutuhan Anda.

            </p>
            
            <h3>Armada/Mobil Travel Lengkap</h3>
            <p>
                Keselamatan dan kenyamanan Anda selama perjalanan adalah fokus utama kami. Kami selalu berupaya meningkatkan
                kualitas layanan dengan merawat dan membersihkan setiap kendaraan secara rutin sebelum keberangkatan. Semua
                armada kami dilengkapi dengan fasilitas unggulan, seperti AC dan sistem audio, agar perjalanan Anda bersama
                <?php echo e(Str::upper(env('APP\_NAME'))); ?> terasa lebih nyaman dan menyenangkan.

            </p>

            <p>
                Berikut adalah beberapa jenis armada/mobil travel yang akan menemani perjalanan Anda:
            </p>
            <ul>
                <li>Mini Bus</li>
                <li>Elf Long</li>
                <li>Hiace Commuter</li>
                <li>Hiace Premio</li>
                <li>Innova Reborn</li>
                <li>Innova Grand New</li>
                <li>Avanza New</li>
                <li>Calya</li>
                <li>Xenia</li>
            </ul>
            <p>
                Mobil yang telah kami sebutkan tidak bisa dipilih jika menggunakan layanan travel reguler. Tapi jika anda
                memesan carter drop atau carter pulang pergi (pp), maka anda bisa memilih mobil/armada yang tersedia:
            </p>
            <iframe class="w-full h-auto aspect-video mb-3"
                src="https://www.youtube.com/embed/JkQtbMABGUo?si=Yjw3V54n_MqENcZ9&autoplay=1" title="YouTube video player"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen>
            </iframe>
            <p>
                Menarik banget, kan? Yuk, segera pesan travel kamu sekarang juga dan nikmati perjalanan yang nyaman!
            </p>
            
            <h3>Rute Travel Lengkap yang kami layani:</h3>
            <p>
                Kami menyediakan layanan travel ke seluruh penjuru Indonesia, dengan fokus utama pada rute
                <strong><?php echo e($page); ?></strong>. Tersedia berbagai pilihan <a href="<?php echo e(route('arsip-travel')); ?>">rute
                    travel</a> yang dapat memudahkan perjalanan Anda. Jaringan agen kami pun tersebar luas, mulai dari
                tingkat provinsi, kota, kabupaten, hingga kecamatan di seluruh Pulau Sumatera, Jawa, hingga Bal. Kami siap
                melayani kebutuhan transportasi Anda di mana saja.

            </p>
            <p>
                Berikut beberapa rute travel pilihan yang kami rekomendasikan untuk Anda, yang mungkin sesuai dengan
                kebutuhan perjalanan Anda:

            </p>
            <ul>
                <?php $__currentLoopData = $recommendation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a
                            href="<?php echo e(route('jalur-rute-travel', ['asal' => Str::slug($loop->index < 5 ? $travel[0]->name : $travel[1]->name), 'tujuan' => Str::slug($item['name']), 'asalId' => $loop->index < 5 ? $travel[0]->code : $travel[1]->code, 'tujuanId' => $item['code']])); ?>"><?php echo e(Str::title('Travel ' . ($loop->index < 5 ? $travel[0]->name : $travel[1]->name) . ' ' . $item->name)); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
            <h2>Kelebihan Menggunakan <?php echo e($page); ?> PP</h2>
            <p>
                Kami menyediakan layanan travel dengan fokus utama pada kepuasan pelanggan. Siap melayani Anda 24 jam sehari
                untuk perjalanan ke berbagai daerah di seluruh Indonesia. Berikut ini beberapa keunggulan yang membuat jasa
                travel kami menjadi pilihan terbaik untuk perjalanan Anda:
            </p>
            <ul>

                <li>Tarif terjangkau dengan opsi negosiasi harga,</li>
                <li>Pembayaran dilakukan setelah Anda sampai di tujuan,</li>
                <li>Fleksibel dengan layanan pembatalan, pengembalian, dan perubahan jadwal,</li>
                <li>Penjemputan langsung dari rumah Anda,</li>
                <li>Tersedia layanan carter sekali jalan maupun pulang-pergi,</li>
                <li>Kendaraan selalu bersih dan dilengkapi AC,</li>
                <li>Layanan travel reguler selama 24 jam,</li>
                <li>Sistem door-to-door untuk keberangkatan dan pulang,</li>
                <li>Perjalanan lebih cepat melalui jalur tol,</li>
                <li>Gratis bonus makan dan minuman.</li>


            </ul>
            
            <h2>Cara Mudah Memesan Travel</h2>
            <p>
                Proses pemesanan <?php echo e($page); ?> sangat praktis dan tanpa ribet. Anda tidak perlu datang langsung ke
                garasi; cukup pesan secara online. Layanan pemesanan online kami aktif 24 jam melalui WhatsApp di nomor
                <?php echo e(phone()); ?>. Mohon untuk hanya mengirim pesan chat dan tidak melakukan panggilan suara sembarangan.

            </p>
            <p>Berikut adalah langkah-langkah pemesanan travel secara online: </p>
            <ul>
                <li>Pilih rute perjalanan Anda melalui website kami,</li>
                <li>Klik ikon WhatsApp untuk mulai menghubungi admin,</li>
                <li>Isi data penumpang seperti nama, jenis kelamin, alamat penjemputan, tujuan, dan detail barang bawaan,
                </li>
                <li>Lakukan negosiasi harga jika diperlukan,</li>
                <li>Tunggu jadwal keberangkatan sesuai informasi yang diberikan oleh admin.</li>

            </ul>
            <p>
                Kami selalu menghadirkan promo menarik setiap minggu! Dapatkan diskon hingga 20% per orang.

                Berikut trik untuk mendapatkan promo tersebut:
            <ul>
                <li>Lakukan pemesanan travel di pagi hari sebelum jam 09.00,</li>
                <li>Bagikan pesanan Anda ke media sosial (Instagram, Facebook, dll),</li>
                <li>Kirimkan bukti screenshot kepada admin kami melalui WhatsApp.</li>

            </ul>

            Dengan langkah tersebut, Anda langsung berhak mengklaim diskon spesial dari kami!
            </p>
            
            <h2>Rekomendasi Jasa <?php echo e($page); ?></h2>
            <p>
                Sedang mencari jasa <?php echo e(Str::title('Travel ' . $travel[0]->name)); ?> atau
                <?php echo e(Str::title('Travel ' . $travel[1]->name)); ?> terbaik di Indonesia? Tenang, Anda berada di tempat yang
                tepat! <?php echo e(Str::upper(env('APP_NAME'))); ?> siap membantu Anda menemukan agen travel terpercaya yang akan
                mengantar Anda dengan aman dan nyaman sampai tujuan.

            </p>
            <p>
                Setiap layanan travel tentu memiliki keunggulan dan kekurangan tersendiri. Oleh karena itu, penting bagi
                Anda untuk memilih jasa travel yang paling sesuai dengan kebutuhan perjalanan Anda, baik dari segi harga,
                fasilitas, kenyamanan, maupun keamanannya.
            </p>
            
            <h2>Tips travel agar lebih nyaman dan aman</h2>
            <p>
                Perjalanan dengan jasa travel umumnya menempuh jarak jauh dan memerlukan waktu yang tidak sebentar, terutama
                pada rute yang satu ini. Layanan ini biasanya digunakan untuk mobilitas antar kota, seperti dari
                <?php echo e(Str::title($travel[0]->name . ' ke ' . $travel[1]->name)); ?> maupun sebaliknya,
                <?php echo e(Str::title($travel[1]->name . ' ke ' . $travel[0]->name)); ?>. Bahkan, banyak penumpang memanfaatkan
                travel untuk bepergian antar provinsi hingga lintas pulau, sehingga durasi perjalanan bisa mencapai beberapa
                jam atau lebih.

            </p>
            <p>
                Agar tetap sehat dan bugar selama perjalanan serta tiba di tujuan dengan kondisi prima, ada beberapa hal
                yang perlu Anda persiapkan. Berikut tips yang bisa Anda ikuti:
            </p>
            <ul>
                <li>Pesan tiket jauh-jauh hari untuk mendapatkan harga terbaik dan memastikan ketersediaan tempat duduk.
                </li>
                <li>Konfirmasi ulang jadwal keberangkatan dan titik penjemputan kepada admin sebelum hari H.</li>
                <li>Siapkan identitas diri dan data lengkap saat memesan, seperti nama, alamat jemput, dan nomor yang bisa
                    dihubungi.</li>
                <li>Bawa barang seperlunya dan hindari membawa bawaan berlebihan agar perjalanan lebih nyaman.</li>
                <li>Datang lebih awal ke lokasi penjemputan untuk menghindari keterlambatan.</li>
                <li>Pastikan HP Anda aktif selama perjalanan agar mudah dihubungi oleh sopir atau pihak travel.</li>
                <li>Jaga kebersihan dan kenyamanan bersama selama di dalam kendaraan.</li>
                <li>Jika ada perubahan jadwal, segera hubungi admin untuk penyesuaian.</li>
            </ul>

            
            <h2>Kesimpulan</h2>

            <p>
                Kami menghadirkan layanan travel dengan harga terjangkau dan berbagai keunggulan, mulai dari pilihan armada
                yang beragam hingga jadwal keberangkatan yang fleksibel. Proses pemesanan juga sangat mudah dan praktis.
                Jadi, tunggu apa lagi? Segera atur perjalanan Anda ke <strong><?php echo e($page); ?></strong> untuk tanggal
                <?php echo e(\Carbon\Carbon::now()->addDay(5)->locale('id')->isoFormat('D MMMM YYYY')); ?>!
            </p>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17c4a23673a4440a1bb06c8c7bab4d4b)): ?>
<?php $attributes = $__attributesOriginal17c4a23673a4440a1bb06c8c7bab4d4b; ?>
<?php unset($__attributesOriginal17c4a23673a4440a1bb06c8c7bab4d4b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17c4a23673a4440a1bb06c8c7bab4d4b)): ?>
<?php $component = $__componentOriginal17c4a23673a4440a1bb06c8c7bab4d4b; ?>
<?php unset($__componentOriginal17c4a23673a4440a1bb06c8c7bab4d4b); ?>
<?php endif; ?>



        
        <?php if (isset($component)) { $__componentOriginalce3cc09b41fabec0e4da8b4d854711be = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce3cc09b41fabec0e4da8b4d854711be = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.article-right','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.article-right'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php if (isset($component)) { $__componentOriginal5379d7c313a3003ffeb1e9f8c8b1be8a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5379d7c313a3003ffeb1e9f8c8b1be8a = $attributes; } ?>
<?php $component = App\View\Components\Booking::resolve(['page' => $page] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('booking'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Booking::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5379d7c313a3003ffeb1e9f8c8b1be8a)): ?>
<?php $attributes = $__attributesOriginal5379d7c313a3003ffeb1e9f8c8b1be8a; ?>
<?php unset($__attributesOriginal5379d7c313a3003ffeb1e9f8c8b1be8a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5379d7c313a3003ffeb1e9f8c8b1be8a)): ?>
<?php $component = $__componentOriginal5379d7c313a3003ffeb1e9f8c8b1be8a; ?>
<?php unset($__componentOriginal5379d7c313a3003ffeb1e9f8c8b1be8a); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce3cc09b41fabec0e4da8b4d854711be)): ?>
<?php $attributes = $__attributesOriginalce3cc09b41fabec0e4da8b4d854711be; ?>
<?php unset($__attributesOriginalce3cc09b41fabec0e4da8b4d854711be); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce3cc09b41fabec0e4da8b4d854711be)): ?>
<?php $component = $__componentOriginalce3cc09b41fabec0e4da8b4d854711be; ?>
<?php unset($__componentOriginalce3cc09b41fabec0e4da8b4d854711be); ?>
<?php endif; ?>


     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159f23c1702f2667f1808a4b0622f0f8)): ?>
<?php $attributes = $__attributesOriginal159f23c1702f2667f1808a4b0622f0f8; ?>
<?php unset($__attributesOriginal159f23c1702f2667f1808a4b0622f0f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159f23c1702f2667f1808a4b0622f0f8)): ?>
<?php $component = $__componentOriginal159f23c1702f2667f1808a4b0622f0f8; ?>
<?php unset($__componentOriginal159f23c1702f2667f1808a4b0622f0f8); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travel\armantrans.com\resources\views/pages/travel.blade.php ENDPATH**/ ?>