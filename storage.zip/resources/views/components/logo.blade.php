<a href="{{ route('beranda') }}" class="block w-16 md:w-20">
    <img class="w-full h-auto" loading="lazy" src="{{ $light ? asset('img/travel.png') : asset('img/travel.png') }}"
        alt="Logo {{ config('app.name') }}">
</a>
